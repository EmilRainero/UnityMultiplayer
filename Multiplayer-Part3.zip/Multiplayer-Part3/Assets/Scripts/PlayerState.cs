using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct PlayerState
{
    public Vector3 position;
    public Quaternion rotation;
}
