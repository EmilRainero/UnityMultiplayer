using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput
{
    public sbyte forward;
    public sbyte rotate;
}
