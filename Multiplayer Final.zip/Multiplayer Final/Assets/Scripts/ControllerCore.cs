using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public struct WorldStatePlayer
{
    public uint netId;
    public PlayerState state;
}

public struct WorldState
{
    public int timestamp;
    public int numberPlayers;
    public WorldStatePlayer[] players;
}

public class ControllerCore : NetworkBehaviour
{
    [SyncVar(hook = "OnWorldStateChanged")]
    public WorldState worldState;

    public WorldState lastWorldState;

    private int localTimestamp;
    private int nextSendTime;
    private Controller controller;

    #region SINGLETON PATTERN
    private static ControllerCore instance;
    public static ControllerCore Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<ControllerCore>();
                if (instance == null)
                {
                    GameObject obj = new GameObject("ControllerCore");
                    instance = obj.AddComponent<ControllerCore>();
                }
            }
            return instance;
        }
    }

    private void Awake()
    {
        // if the singleton hasn't been initialized yet
        if (instance != null && instance != this)
        {
            Destroy(this.gameObject);
            return;//Avoid doing anything else
        }
        instance = this;
        DontDestroyOnLoad(this.gameObject);
    }
    #endregion


    // Use this for initialization
    void Start () {
        controller = Controller.Instance;
        lastWorldState.timestamp = -1;
    }

    void FixedUpdate()
    {
        if (isServer)
        {
            SendWorldState();
        }
        localTimestamp++;
    }

    private void SendWorldState()
    {
        if (localTimestamp >= nextSendTime)
        {
            if (controller.players.Count > 0)
            {
                WorldStatePlayer[] p = CreateWorldStatePlayerArray();

                WorldState ws = new WorldState()
                {
                    timestamp = localTimestamp,
                    numberPlayers = controller.players.Count,
                    players = p
                };

                // send worldstate to all clients
                worldState = ws;
                controller.logBytesOut.AddEntry(Time.time, 8 + controller.players.Count * (4 + System.Runtime.InteropServices.Marshal.SizeOf(typeof(PlayerState))));
            }
            nextSendTime = localTimestamp + Settings.ServerSendWorlStateToClientsFrequency;
        }
    }

    private WorldStatePlayer[] CreateWorldStatePlayerArray()
    {
        WorldStatePlayer[] p = new WorldStatePlayer[controller.players.Count];
        int index = 0;
        foreach (Player player in controller.players)
        {
            p[index].netId = player.netId.Value;
            p[index].state = player.serverState;
            index++;
        }

        return p;
    }

    void OnWorldStateChanged(WorldState newState)
    {
        if (controller == null)
            return;

        if (lastWorldState.timestamp == -1)
        {
            lastWorldState = newState;
        }
        worldState = newState;
        string players = "[";

        for (int i=0; i<newState.players.Length; i++)
        {
            players += newState.players[i].netId + " ";
        }
        players = players.TrimEnd() + "]";

        //Debug.Log(string.Format("OnWorldStateChanged  timestamp: {0}  players: {1}  ids: {2}",
        //   newState.timestamp, newState.numberPlayers, players));

        for (int i = 0; i < newState.players.Length; i++)
        {
            //Debug.Log(string.Format("Player netId: {0}  position: ({1}, {2}, {3})",
            //    newState.players[i].netId,
            //    newState.players[i].state.position.x,
            //    newState.players[i].state.position.y,
            //    newState.players[i].state.position.z
            //    ));
            Player player = FindPlayerByNetId(newState.players[i].netId);
            if (player == null)
            {
                Debug.Log("Could not find player");
                continue;
            }

            //if (newState.players[i].state.timestamp != player.serverState.timestamp)
            {
                player.serverState = newState.players[i].state;
                player.OnServerStateChanged(newState.players[i].state);
            }
        }
        lastWorldState = worldState;

    }

    

    void OnPingChanged(int newPing)
    {
        Debug.Log(string.Format("{0} - got ping response {1}", localTimestamp, newPing));
        //latency = localTimestamp - oldPing;
        //Debug.Log("Latency " + latency);
    }

    private Player FindPlayerByNetId(uint netId)
    {
        foreach (Player player in controller.players)
        {
            if (player.netId.Value == netId)
                return player;
        }
        return null;
    }
}
