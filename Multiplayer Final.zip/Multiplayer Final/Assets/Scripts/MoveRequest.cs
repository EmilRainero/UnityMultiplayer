﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MoveRequest
{
    public int serverTimestamp;
    public int serverEstimatedTimestamp;
    public Player player;
    public PlayerInput playerInput;
}
