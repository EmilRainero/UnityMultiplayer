using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Settings
{
    public const int  ClientSendCommandsToServerFrequency = 5; // ticks
    public const int  ClientMeasureLatencyFrequency = 100; // ticks
    public const int  ServerMaxNumberCommandsToProcess = 40;
    public const bool ServerFindGameSnapshot = true;
    public const int  ServerGameSnapshotInterval = 1;
    public const int  ServerGameSnapshotDuration = 1000;
    public const int  ServerProcessQueuedMovesFrequency = 2;
    public const int  ServerSendWorlStateToClientsFrequency = 1;
    public const float PlayerMoveSpeed = 5f;
    public const float PlayerRotateSpeed = 50f;
    public const float PlayerPartRotateSpeed = 36f;
    public const float PlayerFixedUpdateInterval = .02f;
    public const float PlayerLerpEasing = 0.1f;
    public const float PlayerLerpSpacing = 1.0f;
}

