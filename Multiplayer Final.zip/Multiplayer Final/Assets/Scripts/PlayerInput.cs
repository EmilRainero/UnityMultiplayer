﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerInput
{
    public int lastServerTimestamp;
    public int clientTimestamp;
    public sbyte forward; // -1 to 1
    public sbyte rotate; // -1 to 1
    public sbyte partRotate; // -1 to 1
    public bool fire;
    public bool fired;
    public float averageLatency;
}
