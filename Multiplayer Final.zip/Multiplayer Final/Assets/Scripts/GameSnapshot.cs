using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public struct PlayerInformation
{
    public Vector3 position;
}

public class GameSnapshot<P> where P : Component
{
    public int time;
    public Dictionary<P, PlayerInformation> players;

    public GameSnapshot(int t = 0)
    {
        players = new Dictionary<P, PlayerInformation>();
        time = t;
    }

    public void AddPlayer(P player, PlayerInformation info)
    {
        players.Add(player, info);
    }

    public override bool Equals(System.Object obj)
    {
        if (obj == null)
            return false;
        GameSnapshot<P> s = obj as GameSnapshot<P>;
        if ((System.Object)s == null)
            return false;

        return time == s.time;
    }

    public bool Equals(GameSnapshot<P> s)
    {
        if ((object)s == null)
            return false;

        return time == s.time;
    }

    public override int GetHashCode()
    {
        return base.GetHashCode();
    }

}
