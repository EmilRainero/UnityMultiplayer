using UnityEngine;

public class Bullet : MonoBehaviour
{
    void OnTriggerEnter(Collider other)
    {
        var hit = other.gameObject;
        var hitPlayer = hit.GetComponent<Player>();
        if (hitPlayer != null)
        {
            Destroy(gameObject);
        }
    }
}
