using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

[NetworkSettings(channel=2)] public class Player : NetworkBehaviour {
	[SyncVar] Color color;

    //[SyncVar(hook="OnServerStateChanged")]
    public PlayerState serverState;

    [SyncVar(hook = "OnInitialStateChanged")]
    public PlayerState initialState;
    public bool initialized = false;

    [SyncVar] public short ping = 999;

    public GameObject bulletPrefab;
    public Transform partToRotate;
    public Transform partFirePosition;

    private List<PlayerInput> pendingMoves;
    private List<PlayerInput> sendToServerPlayerInputs;

    private int localTimestamp;

    private PlayerState predictedState;
    private Controller controller;
    private bool usePrediction = true;

    private int maxX = 30;
    private int maxZ = 30;
    private bool autoMove = false;
    private int clientLastFireTime;

    private int nextSendTime;
    private int nextLatencyRequestTime;
    private SlidingAverage averageLatency;

    void Awake ()
    {
		InitState();
    }

    public override float GetNetworkSendInterval()
    {
        return 0.02f;
    }

    void Start ()
    {
        if (isLocalPlayer)
        {
            averageLatency = new SlidingAverage(10);
            pendingMoves = new List<PlayerInput>();
            sendToServerPlayerInputs = new List<PlayerInput>();
            UpdatePredictedState();
        }
        SyncState(true);
        SyncColor();

        SetupController();

        SetupCamera();
    }

    private void SetupController()
    {
        controller = Controller.Instance;
        controller.isServer = isServer;
        controller.AddPlayer(this);
    }

    private void SetupCamera()
    {
        if (isLocalPlayer)
        {
            FollowTrackingCamera ftc = Camera.main.GetComponent<FollowTrackingCamera>();
            ftc.target = transform;
            ftc.enabled = true;
        }
    }

    void FixedUpdate()
    {
        if (isLocalPlayer)
        {
            HandlePlayerInput();
            SendCommandsToServer();
        }
        SyncState(false);
        localTimestamp++;
    }

    private void HandlePlayerInput()
    {
        PlayerInput playerInput = GetPlayerInput();

        if (playerInput != null)
        {
            EnqueuePlayerInput(playerInput);
        }

        if (Input.GetKeyDown(KeyCode.M))
            autoMove = !autoMove;

        // move forward and rotate test
        if (autoMove)
        {
            EnqueuePlayerInput(new PlayerInput()
            {
                clientTimestamp = localTimestamp,
                lastServerTimestamp = serverState.timestamp,
                forward = 1,
                rotate = 1,
                partRotate = 1,
                fire = (localTimestamp % 100 == 0), // 2 seconds
                averageLatency = averageLatency.Average
            });
        }
    }

    private void SendCommandsToServer()
    {
        if (isLocalPlayer && nextSendTime < localTimestamp)
        {
            bool requestAcknowledgement = nextLatencyRequestTime <= localTimestamp;
            if (requestAcknowledgement)
            {
                nextLatencyRequestTime = localTimestamp + Settings.ClientMeasureLatencyFrequency;
            }

            nextSendTime = localTimestamp + Settings.ClientSendCommandsToServerFrequency;
            // send even if no inputs - request will help calculate latency
            if (sendToServerPlayerInputs.Count > 0 || requestAcknowledgement)
            {
                PlayerInput[] a = sendToServerPlayerInputs.ToArray();
                CmdMoveArray(a, localTimestamp, requestAcknowledgement);
                sendToServerPlayerInputs.Clear();
            }
        }
    }

    private void EnqueuePlayerInput(PlayerInput playerInput)
    {
        pendingMoves.Add(playerInput);
        UpdatePredictedState();
        sendToServerPlayerInputs.Add(playerInput);
    }

    private PlayerInput GetPlayerInput()
    {
        PlayerInput playerInput = new PlayerInput();
        playerInput.clientTimestamp = localTimestamp;
        playerInput.averageLatency = averageLatency.Average;
        playerInput.lastServerTimestamp = serverState.timestamp;
        playerInput.forward += (sbyte)(Input.GetKey(KeyCode.W) ? 1 : 0);
        playerInput.forward += (sbyte)(Input.GetKey(KeyCode.S) ? -1 : 0);
        playerInput.rotate += (sbyte)(Input.GetKey(KeyCode.D) ? 1 : 0);
        playerInput.rotate += (sbyte)(Input.GetKey(KeyCode.A) ? -1 : 0);
        playerInput.partRotate += (sbyte)(Input.GetKey(KeyCode.RightArrow) ? 1 : 0);
        playerInput.partRotate += (sbyte)(Input.GetKey(KeyCode.LeftArrow) ? -1 : 0);
        playerInput.fire = Input.GetKeyDown(KeyCode.Space);
        if (playerInput.forward == 0 && playerInput.rotate == 0 && playerInput.partRotate == 0 && !playerInput.fire)
            return null;
        //Debug.Log("GetPlayerInput " + playerInput.clientTimestamp);
        return playerInput;
    }

    [Command(channel = 0)]
    void CmdMoveArray(PlayerInput[] playerInputs, int clientTimeStampWhenSent, bool acknowledge)
    {
        if (acknowledge)
        {
            TargetDoAcknowledgeRequest(connectionToClient, clientTimeStampWhenSent);
        }
        foreach (PlayerInput playerInput in playerInputs)
        {
            int latency = Mathf.RoundToInt(playerInput.averageLatency);

            int serverTimeWhenInputHappened = controller.localTimestamp - latency - (clientTimeStampWhenSent - playerInput.clientTimestamp);
            //Debug.Log(string.Format(
            //    "Server: at time {0} {4} got input of localTimeWhenSent {1} clienttime {2}  set to servertime {3}",
            //    controller.localTimestamp, localTimeWhenSent, playerInput.clientTimestamp, serverTimeWhenInputHappened,
            //    controller.gameSnapshots.ToString()));
            controller.QueueMove(this, playerInput, localTimestamp, serverTimeWhenInputHappened); 
        }
    }

    [Server] void InitState ()
    {
		Color[] colors = {Color.blue, Color.cyan, Color.green, Color.magenta, Color.red, Color.yellow};
		color = colors[UnityEngine.Random.Range(0, colors.Length)];
        serverState = new PlayerState {
            timestamp = 0,
            position = new Vector3(UnityEngine.Random.Range(-maxX, maxX), 0, UnityEngine.Random.Range(-maxZ, maxZ)),
            rotation = Quaternion.Euler(0, 0, 0),
            partRotation = Quaternion.Euler(0, 0, 0)
        };
        initialState = serverState;
    }
	
	public PlayerState ProcessPlayerInput(PlayerState previous, PlayerInput playerInput, bool fromServer = false, 
        int serverTimestamp = 0, int serverEstimatedTimestamp = 0)
    {
        // handle fire
        if (playerInput.fire && !playerInput.fired)
        {
            if (fromServer)
            {
                //Debug.Log("FIRE on server  serverTime: " + serverTimestamp + " client: " + playerInput.clientTimestamp + " server: " + playerInput.lastServerTimestamp);
                controller.Fire(previous, bulletPrefab, partToRotate, partFirePosition, playerInput.clientTimestamp, serverEstimatedTimestamp, ref clientLastFireTime);
                playerInput.fire = true;
            }
        }

        Vector3 newPosition = previous.position;
        Quaternion newRotation = previous.rotation;

        if (playerInput.rotate != 0)
        {
            newRotation = previous.rotation *
                Quaternion.Euler(Vector3.up * Settings.PlayerFixedUpdateInterval * Settings.PlayerRotateSpeed * playerInput.rotate);
        }
        if (playerInput.forward != 0)
        {
            newPosition = previous.position +
                newRotation * Vector3.forward * // the direction to move
                playerInput.forward * Settings.PlayerFixedUpdateInterval * // forward or back
                Settings.PlayerMoveSpeed;
        }

        // now the part to rotate
        Quaternion newPartRotation = previous.partRotation;
        if (partToRotate != null )
        {
            newPartRotation = previous.partRotation * Quaternion.Euler(new Vector3(0, .02f * Settings.PlayerPartRotateSpeed * playerInput.partRotate, 0));
        }

        return new PlayerState
        {
            timestamp = previous.timestamp + 1,
            position = newPosition,
            rotation = newRotation,
            partRotation = newPartRotation
        };
	}

    public void OnInitialStateChanged (PlayerState newState)
    {
        serverState = newState;
        initialized = true;
        Debug.Log(string.Format("Initial state changed ({0}, {1} {2})",
            serverState.position.x, serverState.position.y, serverState.position.z));
        SyncState(true);
    }

    public void OnServerStateChanged (PlayerState newState)
    {
        serverState = newState;
        //Debug.Log(string.Format("OnServerStateChanged servertime: {0}  predicted: {1}" , serverState.timestamp, predictedState.timestamp));
		if (pendingMoves != null) {
			while (pendingMoves.Count > (predictedState.timestamp - serverState.timestamp)) {
                pendingMoves.RemoveAt(0);
			}
            //Debug.Log(string.Format("{0} pending moves", pendingMoves.Count));
			UpdatePredictedState();
		}
	}
	
	private void SyncColor ()
    {
        Color c = (isLocalPlayer ? Color.white : Color.grey) * color;
        foreach (Renderer r in GetComponentsInChildren<Renderer>())
            r.material.color = c;
    }
	
	public void SyncState (bool init)
    {
        PlayerState stateToRender;
        stateToRender = isLocalPlayer ? predictedState : serverState;
        if (!usePrediction)
            stateToRender = serverState;
        Vector3 target = Settings.PlayerLerpSpacing * stateToRender.position; 
		transform.position = init ? target : Vector3.Lerp(transform.position, target, Settings.PlayerLerpEasing);
        transform.rotation = init ? stateToRender.rotation : Quaternion.Lerp(transform.rotation, stateToRender.rotation, Settings.PlayerLerpEasing);
        if (partToRotate != null)
        {
            partToRotate.localRotation = Quaternion.Lerp(partToRotate.localRotation, stateToRender.partRotation, Settings.PlayerLerpEasing);
        }
    }
	
	public void UpdatePredictedState ()
    {
		predictedState = serverState;
		foreach (PlayerInput playerInput in pendingMoves) {
			predictedState = ProcessPlayerInput(predictedState, playerInput);
		}
	}

    //public void SendPingRequest()
    //{
    //    if (isServer)
    //        return;

    //    CmdPingRequest(localTimestamp);
    //    //Debug.Log(string.Format("{0} - Send Ping", localTimestamp));
    //}

    [TargetRpc]
    public void TargetDoAcknowledgeRequest(NetworkConnection target, int timestamp)
    {
        averageLatency.Add((localTimestamp - timestamp) / 2);
        Debug.Log("Average latency: " + averageLatency.Average);
    }

    //[Command(channel = 0)]
    //void CmdPingRequest(int timestamp)
    //{
    //    //Debug.Log("CmdPingRequest");
    //    TargetDoAcknowledgeRequest(connectionToClient, timestamp);
    //}

    void OnDestroy()
    {
        Camera camera = Camera.main;
        if (camera != null)
        {
            FollowTrackingCamera ftc = camera.GetComponent<FollowTrackingCamera>();
            if (ftc != null)
                ftc.enabled = false;
        }

        controller.RemovePlayer(this);
    }
}
