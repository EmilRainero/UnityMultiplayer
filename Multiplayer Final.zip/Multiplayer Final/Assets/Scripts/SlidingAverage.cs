using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SlidingAverage
{
    private int maxEntries;
    private Queue<float> entries;
    public float Average
    {
        get
        {
            float sum = 0;

            if (entries.Count == 0)
                return 0f;

            foreach (float entry in entries)
            {
                sum += entry;
            }
            return sum / (float) entries.Count;
        }
    }

    public SlidingAverage(int max)
    {
        maxEntries = max;
        entries = new Queue<float>();
    }

    public void Add(float entry)
    {
        entries.Enqueue(entry);
        while (entries.Count > maxEntries)
            entries.Dequeue();
    }

}
