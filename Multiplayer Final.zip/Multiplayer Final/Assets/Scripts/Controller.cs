using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class Controller : MonoBehaviour // : GenericSingletonClass<Controller>
{
    public List<Player> players;
    Queue<MoveRequest> queuedMoves;
    public bool isServer = false;
    
    float processQueuedMovesFrequency = .02f;
    private float nextSendTime;

    public LogStats logBytesIn;
    public LogStats logBytesOut;

    public GameSnapshots<Player> gameSnapshots;
    public int localTimestamp;

#region SINGLETON PATTERN
    private static Controller instance;
    public static Controller Instance
    {
        get
        {
            if (instance == null)
            {
                instance = FindObjectOfType<Controller>();
                if (instance == null)
                {
                    GameObject obj = new GameObject("Controller");
                    instance = obj.AddComponent<Controller>();
                }
            }
            return instance;
        }
    }

    private void Awake()
    {
        // if the singleton hasn't been initialized yet
        if (instance != null && instance != this)
        {
            Destroy(this.gameObject);
            return;//Avoid doing anything else
        }
        instance = this;
        DontDestroyOnLoad(this.gameObject);
    }
#endregion

    // Use this for initialization
    void Start () {
        players = new List<Player>();
        queuedMoves = new Queue<MoveRequest>();
        gameSnapshots = new GameSnapshots<Player>(Settings.ServerGameSnapshotInterval, Utils.MillisecondsToTicks(Settings.ServerGameSnapshotDuration));

        logBytesIn = new LogStats(10);
        logBytesOut = new LogStats(10);
    }

    public void SaveGameSnapshot(int currentTime)
    {
        //lock(players)
        {
            gameSnapshots.SaveGameSnapshot(players, currentTime);
        }
    }

    void FixedUpdate()
    {
        if (isServer && nextSendTime < Time.time)
        {
            ProcessQueuedMoves();
            nextSendTime = Time.time + processQueuedMovesFrequency;
        }
        if (isServer)
        {
            localTimestamp++;
            SaveGameSnapshot(localTimestamp);
        }
    }

    public void AddPlayer(Player player)
    {
        players.Add(player);
    }

    public void RemovePlayer(Player player)
    {
        players.Remove(player);
    }

    private void ProcessQueuedMoves()
    {
        //lock(queuedMoves)
        {
            if (queuedMoves.Count != 0)
            {
                //Debug.Log("ProcessQueuedMoves " + queuedMoves.Count);
                Dictionary<Player, PlayerState> playerStates = new Dictionary<Player, PlayerState>();
                int numberProcessed = 0;

                while (queuedMoves.Count > 0 && numberProcessed < Settings.ServerMaxNumberCommandsToProcess)
                {
                    MoveRequest request = queuedMoves.Dequeue();
                    
                    //FindGameSnapshot(request.serverEstimatedTimestamp);
                    if (!playerStates.ContainsKey(request.player))
                        playerStates[request.player] = request.player.serverState;

                    playerStates[request.player] = request.player.ProcessPlayerInput(playerStates[request.player], request.playerInput, true, request.serverTimestamp, request.serverEstimatedTimestamp);
                    numberProcessed++;
                }
                foreach (KeyValuePair<Player, PlayerState> pair in playerStates)
                {
                    pair.Key.serverState = pair.Value;
                    pair.Key.OnServerStateChanged(pair.Value);
                    logBytesOut.AddEntry(Time.time, players.Count * System.Runtime.InteropServices.Marshal.SizeOf(typeof(PlayerState)));
                }
                //queuedMoves.Clear();
            }
        }
    }

    public bool Fire(PlayerState previous, GameObject bulletPrefab, Transform partToRotate, Transform firePosition, int clientFireTime, int serverEstimatedTimestamp, ref int lastFireTime)
    {
        //Debug.Log(string.Format("clientFireTime: {0}  lastFireTime: {1}", clientFireTime, lastFireTime));
        if (clientFireTime - lastFireTime < 100)
        {
            //Debug.Log("Skipped firing");
            return false;
        }

        FindGameSnapshot(serverEstimatedTimestamp);

        // create the bullet object from the bullet prefab
        var bullet = (GameObject)Instantiate(
            bulletPrefab,
            firePosition.position, //partToRotate.position + partToRotate.forward * 2f + new Vector3(0, .5f, 0),
            partToRotate.rotation);
        //Quaternion.identity);

        // make the bullet move away in front of the player
        bullet.GetComponent<Rigidbody>().velocity = partToRotate.forward * 5;
        logBytesOut.AddEntry(Time.time, players.Count * 30); // 30 is a guess

        // spawn the bullet on the clients
        NetworkServer.Spawn(bullet);

        // make bullet disappear after 2 seconds
        Destroy(bullet, 2.0f);

        lastFireTime = clientFireTime;
        return true;
    }

    public void QueueMove(Player p, PlayerInput input, int serverTime, int serverEstimatedTime)
    {
        logBytesIn.AddEntry(Time.time, 4 + 13);

        queuedMoves.Enqueue(new MoveRequest() { player = p, playerInput = input, serverTimestamp = serverTime, serverEstimatedTimestamp = serverEstimatedTime });
    }

    Vector2 setPoint(Vector2 point)
 	{ 
 		point.x = (int)point.x; 
 		point.y = (int)point.y; 
 		return point; 
 	}

    void DrawLine(Vector2 pointA, Vector2 pointB, float width, Color color)
 	{ 
 		pointA = setPoint(pointA); 
 		pointB = setPoint(pointB); 
 		Texture2D lineTex = new Texture2D(1, 1);   
 		Matrix4x4 matrixBackup = GUI.matrix;
        Color oldcolor = GUI.color;

        GUI.color = color;		 
 		float angle = Mathf.Atan2(pointB.y - pointA.y, pointB.x - pointA.x) * 180f / Mathf.PI; 
 
 		GUIUtility.RotateAroundPivot (angle, pointA); 
 		GUI.DrawTexture (new Rect(pointA.x, pointA.y, (pointA - pointB).magnitude, width), lineTex); 
 		GUI.matrix = matrixBackup;
        GUI.color = oldcolor;
 	}

    public void FindGameSnapshot(int serverTimeWhenInputHappened)
    {
#pragma warning disable 0162 
        if (Settings.ServerFindGameSnapshot)
        {
            gameSnapshots.FindGameSnapshotPair(serverTimeWhenInputHappened);
        }
#pragma warning restore 0162 
    }

    void DrawQuad(Rect position, Color color, Color borderColor)
    {
        Texture2D texture = new Texture2D(1, 1);
        texture.SetPixel(0, 0, color);
        texture.Apply();
        GUI.skin.box.normal.background = texture;
        GUI.Box(position, GUIContent.none);

        DrawLine(new Vector2(position.xMin, position.yMin), new Vector2(position.xMax, position.yMin), 2f, borderColor);
        DrawLine(new Vector2(position.xMin, position.yMax), new Vector2(position.xMax, position.yMax), 2f, borderColor);
        DrawLine(new Vector2(position.xMin, position.yMin), new Vector2(position.xMin, position.yMax), 2f, borderColor);
        DrawLine(new Vector2(position.xMax, position.yMin), new Vector2(position.xMax, position.yMax), 2f, borderColor);
    }

    void OnGUI()
    {
        int w = Screen.width, h = Screen.height;
        GUIStyle style = new GUIStyle();
        style.alignment = TextAnchor.UpperLeft;
        style.fontSize = 14;
        style.normal.textColor = Color.white; // new Color(0.0f, 0.0f, 0.5f, 1.0f);
        style.alignment = TextAnchor.MiddleCenter;

        GUI.Label(new Rect(0, 0, w, 20), "Use ASDW to move, Left/Right arrow to turn turret, SPACE to fire, M to auto move", style);

        style.alignment = TextAnchor.LowerLeft;

        if (!isServer)
            return;
        style.fontSize = 14;

        int y = h - 100;
        DrawQuad(new Rect(0, h-120, 500, 120), new Color(0, 0, 0, .2f), Color.black);
        GUI.Label(new Rect(10, y, w, h * 2 / 100), string.Format("Players: {0}", players.Count), style); y += 20;
        GUI.Label(new Rect(10, y, w, h * 2 / 100), string.Format("Queued: {0}", queuedMoves.Count), style); y += 20;
        GUI.Label(new Rect(10, y, w, h * 2 / 100), string.Format("World Snapshots: {0}", gameSnapshots.Count), style); y += 20;
        GUI.Label(new Rect(10, y, w, h * 2 / 100), string.Format("Updates:  Total {0}  {1}/sec", logBytesOut.numberEntries, 
            Mathf.RoundToInt(logBytesOut.numberEntries / Time.fixedTime)), style); y += 20;
        GUI.Label(new Rect(10, y, w, h * 2 / 100),
            string.Format("Statistics:  In: {0:0.00} K/sec   {1} Total    Out: {2:0.00} K/sec   {3} Total",
                logBytesIn.AverageBytesPerSecond() / 1024, logBytesIn.totalBytes,
                logBytesOut.AverageBytesPerSecond() / 1024, logBytesOut.totalBytes),
            style); y += 20;
    }

}
