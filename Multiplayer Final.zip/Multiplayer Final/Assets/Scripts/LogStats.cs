using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LogStats {

    public ulong totalBytes;
    public int numberEntries;
    public int seconds;

    private struct LogEntry
    {
        public int time;
        public ulong bytes;
    };
    private List<LogEntry> logEntries;

	public LogStats(int seconds = 60)
    {
        this.totalBytes = 0;
        this.numberEntries = 0;
        this.seconds = seconds;
        logEntries = new List<LogEntry>();
    }

    public void AddEntry(float t, int b)
    {
        totalBytes += (ulong) b;
        numberEntries++;

        TrimOldEntries(t);
        if (logEntries.Count == 0)
        {
            logEntries.Add(new LogEntry() { time = (int) t, bytes = (ulong) b});
            return;
        }
        LogEntry entry = logEntries[logEntries.Count - 1];
        if (entry.time != (int) t)
        {
            logEntries.Add(new LogEntry() { time = (int)t, bytes = (ulong)b });
            return;
        }
        entry.bytes += (ulong)b;
        logEntries[logEntries.Count - 1] = entry;
    }

    private void TrimOldEntries(float t)
    {
        while (logEntries.Count > 0 && logEntries[0].time < t - (seconds-1))
        {
            logEntries.RemoveAt(0);
        }
    }

    public float AverageBytesPerSecond()
    {
        ulong total = 0;
        foreach (LogEntry entry in logEntries)
        {
            System.Console.WriteLine(entry.bytes);
            total += entry.bytes;
        }
        return total / (float) seconds;
    }
}
