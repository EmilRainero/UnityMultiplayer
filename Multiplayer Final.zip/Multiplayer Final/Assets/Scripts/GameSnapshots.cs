using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSnapshots<P> where P : Component
{
    List<GameSnapshot<P>> gameSnapshots;
    int interval;
    int maxSnapshots;
    Dictionary<int, GameSnapshot<P>> dictionary;

    public int Count
    {
        get { return gameSnapshots.Count; }
    }

    public GameSnapshots(int _interval, int max)
    {
        gameSnapshots = new List<GameSnapshot<P>>();
        this.interval = _interval;
        this.maxSnapshots = max;
        dictionary = new Dictionary<int, GameSnapshot<P>>();
    }

    public void SaveGameSnapshot(List<P> players, int currentTime)
    {
        if (gameSnapshots.Count == 0 || gameSnapshots[gameSnapshots.Count-1].time + interval <= currentTime)
        {
            //Debug.Log("SaveGameSnapshot " + currentTime + "  total: " + gameSnapshots.Count);
            GameSnapshot<P> snapshot = new GameSnapshot<P>(currentTime);

            if (gameSnapshots.Contains(snapshot))
            {
                return;
            }

            foreach (P player in players)
            {
                PlayerInformation info = new PlayerInformation()
                {
                    position = GetPosition()
                    //position = player.serverState.position // new Vector3(player.serverState.x, player.serverState.y, player.serverState.z)
                };
                snapshot.AddPlayer(player, info);
            }

            gameSnapshots.Add(snapshot);
            dictionary.Add(snapshot.time, snapshot);

            if (gameSnapshots.Count > maxSnapshots)
            {
                dictionary.Remove(gameSnapshots[0].time);
                gameSnapshots.RemoveAt(0);
            }
        }
    }

    public virtual Vector3 GetPosition()
    {
        return Vector3.zero;
    }

    public bool FindGameSnapshotPair(int time)
    {
        if (dictionary.ContainsKey(time))
        {
            Debug.Log(string.Format("FindGameSnapshotPair({0}) [{1}-{2}] Found gamesnapshot",
                time, gameSnapshots[0].time, gameSnapshots[gameSnapshots.Count - 1].time));
            return true;
        }

        if (gameSnapshots.Count < 2)
            return false;

        for (int i=0; i<gameSnapshots.Count-1; i++)
        {
            if (gameSnapshots[i].time <= time && time <= gameSnapshots[i+1].time)
            {
                Debug.Log(string.Format("FindGameSnapshotPair({0}) [{1}-{2}] Found a pair between {3} and {4}", 
                    time, gameSnapshots[0].time, gameSnapshots[gameSnapshots.Count-1].time,
                    gameSnapshots[i].time, gameSnapshots[i + 1].time)); 
                return true;
            }
        }
        Debug.Log(string.Format("FAILED ---------------------- FindGameSnapshotPair time {0} between {1}-{2}",
            time, gameSnapshots[0].time, gameSnapshots[gameSnapshots.Count - 1].time));
        return false;
    }

    public override string ToString()
    {
        return string.Format("[{0}-{1}]", gameSnapshots[0].time, gameSnapshots[gameSnapshots.Count - 1].time);
    }
}
