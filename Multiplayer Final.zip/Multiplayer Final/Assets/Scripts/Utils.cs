using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Utils {

    public static int MillisecondsToTicks(int milliseconds)
    {
        return milliseconds / 20;
    }

    public static Transform FindDeepChild(Transform aParent, string aName)
    {
        var result = aParent.Find(aName);
        if (result != null)
            return result;
        foreach (Transform child in aParent)
        {
            result = FindDeepChild(child, aName);
            if (result != null)
                return result;
        }
        return null;
    }

}
