using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Networking;

public class MyNetworkManager : NetworkManager
{
    private bool isServer = false;

    public override void OnClientConnect(NetworkConnection conn)
    {
        if (isServer)
            return;

        Debug.Log("OnClientConnect");
        ClientScene.AddPlayer(conn, 0);
    }

    public override void OnServerConnect(NetworkConnection conn)
    {
        isServer = true;
    }

    public override void OnClientDisconnect(NetworkConnection conn)
    {
        Debug.Log("OnClientDisconnect");
    }

    public override void OnClientError(NetworkConnection conn, int errorCode)
    {
        Debug.Log("OnClientError " + errorCode);
    }

}
